const fs=require('fs'),path=require('path');
const out=path.join(__dirname,'../outputs/offline-games');fs.mkdirSync(out,{recursive:true});
const mime={'.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.otf':'font/otf','.eot':'application/vnd.ms-fontobject'};
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;');
function data(file){return 'data:'+(mime[path.extname(file)]||'application/octet-stream')+';base64,'+fs.readFileSync(file).toString('base64')}
function css(file){return fs.readFileSync(file,'utf8')
 .replace(/@import\s+url\(["']?([^"')]+)["']?\);/g,(_,p)=>css(path.resolve(path.dirname(file),p)))
 .replace(/url\(\s*['"]?([^"')]+)['"]?\s*\)/g,(all,p)=>p.startsWith('data:')?all:'url("'+data(path.resolve(path.dirname(file),p.split(/[?#]/)[0]))+'")');}
const storage=`window.hyperStorage=(()=>{const values={};return {getItem:k=>Object.prototype.hasOwnProperty.call(values,k)?values[k]:null,setItem:(k,v)=>values[k]=String(v),removeItem:k=>delete values[k],clear:()=>{for(const k in values)delete values[k]}}})();`;
const pages={};
for(const [name,folder,license] of [['2048','2048-master','LICENSE.txt'],['hextris','hextris-gh-pages','LICENSE.md']]){
 const root=path.join(__dirname,'offline-vendor',folder);
 let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 html=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,tag=>{
  const src=tag.match(/\bsrc=["']([^"']+)/i)?.[1];
  if(!src)return tag.includes('google-analytics.com')?'':tag;
  if(/^https?:|^\/\//.test(src))return '';
  let js=fs.readFileSync(path.join(root,src),'utf8');
  if(name==='hextris'){
   if(src==='vendor/js.cookie.js')js='window.Cookies={set:function(){},get:function(){}};';
   js=js.replace(/\blocalStorage\b/g,'hyperStorage');
   if(src==='js/main.js')js=js.replace(/\(function\(\)\{\s*var script = document\.createElement\('script'\);[\s\S]*?document\.head\.appendChild\(script\);\s*\}\)\(\)/,'');
   if(src==='js/initialization.js')js=js.replace(/\(function\(i, s, o, g, r, a, m\)[\s\S]*?ga\('send', 'pageview'\);/,'');
   js=js.replace('$("#pauseBtn").replace(/^.*[\\\\\\/]/, \'\') == "btn_pause.svg"', '$("#pauseBtn").attr("src") == "./images/btn_pause.svg"');
   js=js.replace(/(["'])(\.?\/?images\/[^"']+)\1/g,(_,q,p)=>q+data(path.join(root,p))+q);
  }
  new Function(js);
  return '<script>'+js.replace(/<\/script/gi,'<\\/script')+'</script>';
 });
 html=html.replace(/<link\b[^>]*>/gi,tag=>{
  const href=tag.match(/\bhref=['"]([^'"]+)/i)?.[1];
  if(!/rel=['"]stylesheet/i.test(tag)||!href||/^https?:|^\/\//.test(href))return '';
  return '<style>'+css(path.join(root,href))+'</style>';
 });
 html=html.replace(/(<img\b[^>]*\bsrc=)(['"])([^'"]+)\2/gi,(_,start,q,p)=>start+q+data(path.join(root,p))+q);
 if(name==='2048')html=html.replace(/<p>\s*<strong class="important">Note:[\s\S]*?<\/p>/,'<p>Offline adaptation of Gabriele Cirulli’s 2048. Swipe on the board or use arrow keys. Scores last for this play session.</p>');
 const licenseText=fs.readFileSync(path.join(root,license),'utf8');
 html=html.replace('<head>',`<head><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'"><script>${storage}</script>`);
 html=html.replace('</body>','<details style="position:relative;z-index:9999;background:#fff;color:#222;padding:8px;max-height:200px;overflow:auto"><summary>Credits, license and offline changes</summary><p>Offline adaptation for HYPERSPACE, 2026-10-19: assets embedded; external analytics, ads and fonts removed; Hextris storage uses session memory. Original source: '+(name==='2048'?'https://github.com/gabrielecirulli/2048':'https://github.com/Hextris/hextris')+'. Complete source is supplied in HYPERSPACE-offline-sources.zip.</p><pre style="white-space:pre-wrap">'+esc(licenseText)+'</pre></details></body>');
 pages['offline_'+name]=html;fs.writeFileSync(path.join(out,name+'.html'),html);
 console.log(name,Buffer.byteLength(html));
}
fs.writeFileSync(path.join(out,'pages.json'),JSON.stringify(pages));
