HYPERSPACE OFFLINE GAME SOURCES
Prepared 2026-10-19

2048: https://github.com/gabrielecirulli/2048 (master archive)
Copyright (c) 2014 Gabriele Cirulli. MIT license in LICENSE.txt.

Hextris: https://github.com/Hextris/hextris (gh-pages archive)
Copyright (C) 2018 Logan Engstrom.
GPL-3.0-or-later per upstream README. Full LICENSE.md included.
Upstream vendor and font license files remain in the respective directories.

This archive contains the upstream source trees and the exact packaging script.
To regenerate the modified standalone games with Node.js:
  node work/build-offline-vendor.cjs
Outputs are written to outputs/offline-games/.

Changes made by the packaging script:
- Embed local scripts, fonts and images.
- Remove automatic remote analytics/advertising/font requests.
- Enforce a resource policy that prevents network requests from the games.
- Use session-memory storage for Hextris inside the isolated iframe.
- Add credits/license notices; identify 2048 as an offline adaptation.
- Correct a Hextris pause-button image lookup.

The packaged HTML contains the modified game source, including inline scripts.
No compilation or external package installation is required.
The two games run in separate isolated frames in HYPERSPACE.
Keyboard gameplay tested on desktop; touch controls included by upstream,
but an actual school-managed iPad has not been tested.
